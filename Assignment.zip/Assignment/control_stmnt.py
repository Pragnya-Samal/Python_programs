#if else statement
#Q1check number positive, negative or zero
num = float(input("Enter a number: "))
if num > 0:
    print("The number is positive.")
elif num < 0:
    print("The number is negative.")
else:
    print("The number is zero.")


#Q2check even or odd
num = int(input("Enter an integer: "))
if num % 2 == 0:
    print("The number is even.")
else:
    print("The number is odd.")

#Q3find largest among three numbers
a = float(input("Enter first number: "))
b = float(input("Enter second number: "))
c = float(input("Enter third number: "))
if (a >= b) and (a >= c):
    largest = a
elif (b >= a) and (b >= c):
    largest = b
else:
    largest = c
print("The largest number is:", largest)

#Q4check leap year
year = int(input("Enter a year: "))
if (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0):
    print("leap year is:",year)
else:
    print("not a leap year:",year)
#Q5program to check grade based on marks
marks = float(input("Enter your marks (0-100): "))
if marks >= 90:
    grade = 'A'
elif marks >= 80:
    grade = 'B'
elif marks >= 70:
#Q6check vowel or consonant
char = input("Enter a single alphabet character: ").lower()
if char in 'aeiou':
    print( " vowel.",char)
elif char.isalpha():
    print( " consonant.",char)
else:
    print("Invalid input. Please enter a single alphabet character.")
    